
public class Passager extends Personne {

	private int numéroDeBillet ;
	
	public void setNuméroDeBillet ( int n ) { this.numéroDeBillet = n ; }

	public    int getNuméroDeBillet ( ) { return this.numéroDeBillet ; }

	public Passager( String nom, int age, int numéroDeBillet) {
		super( nom, age) ;
		this.setNuméroDeBillet( numéroDeBillet) ;
	}
	
	public String toString() {
		String res = "Passager[ " ;
		res += super.toString() + ", ";
		res += "n° de billet : " + this.getNuméroDeBillet() + "]";
		return res ;
	}
	
	public boolean equals( Object o ) {
		if ( ! ( o instanceof Passager ) ) 
			return false ;
		Passager p = (Passager) o ;
		return ( super.equals( p ) && this.getNuméroDeBillet() == p.getNuméroDeBillet() ) ;
	}
}




