
public class Mécanicien extends Personnel {

	private String spécialité ;
	
	public void setSpécialité( String spec ) { this.spécialité = spec ; }

	public String getSpécialité( ) { return this.spécialité ; }

	public Mécanicien( String nom, int age, int numéroProfessionnel, String service, String spécialité) {
		super( nom, age, numéroProfessionnel, service );
		this.setSpécialité( spécialité) ;
	}
		
	public String toString() {
		String res = "Mécanicien[ " ;
		res += super.toString() + ", ";
		res += "spécialité : " + this.getSpécialité() + "]" ;
		return res ;
	}

	public boolean equals( Object o ) {
		if ( ! ( o instanceof Mécanicien ) ) 
			return false ;
		Mécanicien m = (Mécanicien) o ;
		return ( super.equals( m ) && this.getSpécialité().equals(  m.getSpécialité() ) ) ;
	}
}




